Examples and example test cases
