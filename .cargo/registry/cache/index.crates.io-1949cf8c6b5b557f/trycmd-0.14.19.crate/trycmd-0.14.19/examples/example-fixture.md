```
$ example-fixture
```
