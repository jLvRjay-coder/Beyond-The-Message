pub mod codspeed;
mod macros;
mod measurement;
mod request;
pub mod utils;
pub mod walltime;
